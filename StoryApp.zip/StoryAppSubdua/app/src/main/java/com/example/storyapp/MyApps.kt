package com.example.storyapp

import android.app.Application

class MyApps: Application()