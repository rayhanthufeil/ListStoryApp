package com.example.storyapp.data

data class UserModel(
    var token: String,
    var isLogin: Boolean
)